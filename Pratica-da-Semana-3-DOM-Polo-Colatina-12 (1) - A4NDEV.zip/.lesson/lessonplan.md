# Rubrica de correção
  ![Grade](assets/F1-M4-Sem03-Praticas-Grade.png)